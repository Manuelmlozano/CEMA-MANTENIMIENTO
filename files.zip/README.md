# CEMA — Mantenimiento Preventivo

Aplicación web para control de tareas de mantenimiento preventivo de planta.

## Archivos

```
cema-mantenimiento/
├── index.html   ← estructura de la página
├── style.css    ← estilos y diseño
├── app.js       ← lógica y datos
└── README.md    ← este archivo
```

## Cómo subir a GitHub Pages (gratis)

### Paso 1 — Crear cuenta en GitHub
Entrá a https://github.com y creá una cuenta gratuita si no tenés.

### Paso 2 — Crear un repositorio nuevo
1. Hacé clic en el botón verde **"New"** (o el "+" arriba a la derecha)
2. Nombre del repositorio: `cema-mantenimiento`
3. Dejá todo lo demás por defecto
4. Hacé clic en **"Create repository"**

### Paso 3 — Subir los archivos
En la página del repositorio vacío:
1. Hacé clic en **"uploading an existing file"**
2. Arrastrá los 3 archivos: `index.html`, `style.css`, `app.js`
3. Escribí un mensaje como "Subida inicial"
4. Hacé clic en **"Commit changes"**

### Paso 4 — Activar GitHub Pages
1. Ir a la pestaña **Settings** del repositorio
2. En el menú izquierdo, clic en **Pages**
3. En "Branch", seleccioná **main** y carpeta **/ (root)**
4. Hacé clic en **Save**

### Paso 5 — ¡Listo!
En unos minutos tu app estará disponible en:
```
https://TU-USUARIO.github.io/cema-mantenimiento/
```

## Cómo agregar tareas permanentes

Para agregar tareas que persistan siempre (no solo en la sesión), editá el array `RAW_TASKS` en `app.js`. Cada tarea tiene este formato:

```js
{
  id: 35,                        // número único
  tarea: 'Descripción',          // nombre de la tarea
  sector: 'Nombre del sector',   // sector de la planta
  resp: 'Nombre Apellido',       // responsable
  period: 7,                     // cada cuántos días
  ultima: '2026-04-16'           // fecha de última ejecución (YYYY-MM-DD)
}
```

## Funciones
- Dashboard con métricas en tiempo real
- Alertas de tareas vencidas y próximas
- Listado con filtros por sector, responsable y estado
- Marcar tareas como realizadas (recalcula próxima fecha)
- Historial de mantenimientos del día
- Agregar nuevas tareas desde la interfaz
